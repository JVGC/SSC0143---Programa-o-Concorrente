/*
Ana Carolina Fainelo de Oliveira 10284542
Beatriz Campos de Almeida de Castro Monteiro 9778619
João Victor Garcia Coelho 10349540
Mateus Virginio Silva 10284156
Matheus Sanchez 9081453
*/

#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include <math.h>
#include <limits.h>

// structs auxiliares que conterão os valores que forem serem calculados
typedef struct cidade{
	int menor;
	int maior;
	double mediana;
	double media;
	double dp;
}Cidade;

typedef struct regiao{
	int menor;
	int maior;
	double mediana;
	double media;
	double dp;
}Regiao;

typedef struct pais{
	int menor;
	int maior;
	double mediana;
	double media;
	double dp;
}Pais;

// variaveis globais e compartilhadas durante o trabalho
int media_mcid, melhor_cidade, mcid_reg, melhor_regiao, media_mr;

// MergeSort retirado do https://www.geeksforgeeks.org/merge-sort/
void merge(int* arr, int l, int m, int r) 
{ 
    int i, j, k; 
    int n1 = m - l + 1; 
    int n2 =  r - m; 
  
   
    int L[n1], R[n2]; 
  
    
    for (i = 0; i < n1; i++) 
        L[i] = arr[l + i]; 
    for (j = 0; j < n2; j++) 
        R[j] = arr[m + 1+ j]; 
  
    
    i = 0; 
    j = 0; 
    k = l; 
    while (i < n1 && j < n2) 
    { 
        if (L[i] <= R[j]) 
        { 
            arr[k] = L[i]; 
            i++; 
        } 
        else
        { 
            arr[k] = R[j]; 
            j++; 
        } 
        k++; 
    } 
  
    while (i < n1) 
    { 
        arr[k] = L[i]; 
        i++; 
        k++; 
    } 
  
    while (j < n2) 
    { 
        arr[k] = R[j]; 
        j++; 
        k++; 
    } 
} 
  
void mergeSort(int* arr, int l, int r) 
{ 
    if (l < r) 
    { 
        int m = l+(r-l)/2; 
  
         
        mergeSort(arr, l, m); 
        mergeSort(arr, m+1, r); 
  
        merge(arr, l, m, r); 
    } 
}

void ordena_cidade(int* brasil, int r, int c, int a, Cidade* cidades){

	int i, j;
	// Ordena todas as cidades
	for(i =0; i < r*c*a; i+=a){
		mergeSort(brasil+i, 0, a-1);
	}

	double dp=0, som=0;
	int cid=0;

	for(i=0; i<(r*c*a); i+=a){// percorre cidades
		for(j=0; j<a; j++){// percorre alunos
			som+=brasil[j+i];
		}
		// calculando a media, e as menores e maiores notas de cada cidade
		cidades[cid].menor = brasil[i];
		cidades[cid].menor = brasil[i+a-1];
		cidades[cid].media = som/a;

		// calculando a mediana de cada cidade
		if(a%2==0) cidades[cid].mediana = (brasil[(i+j)-(a/2)]+brasil[(i+j)-(a/2)-1])/2.0;
		else cidades[cid].mediana = brasil[(i+j)-(a/2)];
		
		// calculando o desvio padrao de cada cidade
		for(int k=0;k<a;k++) dp+= pow(brasil[k+i]-cidades[cid].media, 2);
		dp = dp/(a -1);
		cidades[cid].dp = sqrt(dp);

		// atualizando as variaveis globais de melhor cidade do pais se necessario
		if(cidades[cid].media>media_mcid){
			media_mcid = cidades[cid].media;
			melhor_cidade = cid%(r+1);
			mcid_reg = i/(a*c);
		}

		som=0;
		dp=0;
		cid++;
	}
	return;
}

void ordena_regiao(int* brasil, int r, int c, int a, Regiao* regioes){

	int i, j;
	// Ordena todas as regioes
	for(i =0; i < r*c*a; i+=(a*c)){
		mergeSort(brasil+i, 0, (c*a) -1);
	}


	double dp=0, som=0;
	int reg = 0;
	for(i=0; i<(r*c*a); i+=(a*c)){// percorre regiao
		for(j=0; j<(a*c); j++){// percorre alunos por regiao
			som+=brasil[j+i];
		}

		
		// calculando a media, e as menores e maiores notas de cada regiao
		regioes[reg].menor = brasil[i];
		regioes[reg].maior = brasil[i+(a*c)-1];
		regioes[reg].media = som/(a*c);

		// calculando a mediana de cada regiao

		if((a*c)%2==0) regioes[reg].mediana = (brasil[(i+j)-((a*c)/2)]+brasil[(i+j)-((a*c)/2)-1])/2.0;
		else regioes[reg].mediana = brasil[(i+j)-((a*c)/2)];

		// calculando o desvio padrao de cada regiao
		for(int k=0;k<(a*c);k++) dp+= pow(brasil[k+i]-regioes[reg].media, 2);
		dp = dp/(a*c -1);
		regioes[reg].dp = sqrt(dp);

		// atualizando as variaveis globais de melhor regiao do pais se necessario
		if(regioes[reg].media>media_mr){
			melhor_regiao = reg;
			media_mr = regioes[reg].media;
		}
		som=0;
		dp=0;
		reg++;
	}
	return;
}

void ordena_brasil(int*brasil, int r, int c, int a, Pais* p){
	int aux, i, j;
	// ordenando as notas de todo o pais
	mergeSort(brasil, 0, r*c*a -1);


	double dp=0, som=0;
	// calculando a media e as maiores e menores notas do pais
	for(i=0; i<(r*c*a); i++) som+=brasil[i];
	p->media = som/(r*c*a);
	
	p->menor = brasil[0];
	p->maior = brasil[(r*c*a)-1];
	// calculando a mediana do pais
	if((a*c*r)%2==0) p->mediana = (brasil[(r*a*c)/2]+brasil[((r*a*c)/2)-1])/2.0;
	else p->mediana = brasil[((r*a*c)/2)];
	
	// calculando o desvio padrao do pais
	for(i=0;i<(r*a*c);i++) dp+= pow(brasil[i]-p->media, 2);
	dp = dp/(a*c*r -1);
	p->dp = sqrt(dp);
}

int main(){

	int r, c, a, seed;
	// lendo os parametros do arquivo de entrada e inicializando a seed
	fscanf(stdin, "%d%d%d%d", &r, &c, &a, &seed);
	srand(seed);
	// inicializando as variavies globais
	melhor_cidade = -1;
	melhor_regiao = -1;
	mcid_reg = -1;
	media_mcid = -1;
	media_mr = -1;

	// alocando a matriz e as structs auxiliares
	int* brasil = (int*)calloc(r*c*a, sizeof(int));
	Cidade* cidades = (Cidade*) malloc(sizeof(Cidade)*r*c);

	Regiao* regioes = (Regiao*) malloc(sizeof(Regiao)*r);
	Pais* p = (Pais*)malloc(sizeof(Pais));
	
	// preenchendo a matriz com os valores aleatórios partindo da seed
	for(int i=0; i<r*c*a; i++) brasil[i] = rand()%101;
		
	double start = omp_get_wtime();
	// resolvendo o trabalho em si
	ordena_cidade(brasil, r, c, a, cidades);
	ordena_regiao(brasil, r, c, a, regioes);  
	ordena_brasil(brasil, r, c, a, p);
	start = omp_get_wtime()-start;

	// trabalho resolvido, agora só resta printar na tela tudo em ordem
	for(int i = 0; i < c*r; i++)
		printf("Reg %d - Cid %d: menor: %d, maior: %d, mediana: %.2lf, media: %.2lf e DP: %.2lf\n", i/(r+1), i%(r+1), cidades[i].menor, cidades[i].maior, cidades[i].mediana, cidades[i].media, cidades[i].dp);
	printf("\n\n");

	for(int i = 0; i < r; i++)
		printf("Reg %d - menor: %d, maior: %d, mediana: %.2lf, media: %.2lf e DP: %.2lf\n", i, regioes[i].menor, regioes[i].maior, regioes[i].mediana, regioes[i].media, regioes[i].dp);
	
	printf("\n\n");
	printf("Brasil: menor: %d, maior: %d, mediana: %.2lf, media: %.2lf e DP: %.2lf\n\n", p->menor, p->maior, p->mediana, p->media, p->dp);
	
	printf("Melhor regiao: Regiao %d\n", melhor_regiao);
	printf("Melhor cidade: Regiao %d, Cidade %d\n\n", mcid_reg, melhor_cidade);
	printf("Time: \t %lf \n",start);

	free(brasil);
	free(regioes);
	free(cidades);
	free(p);

	return 0;
}